import React from 'react'
import Navbar from '../components/navbar'
import DashboardComp from '../components/dashboardComp'

export default function Page() {
  return (
    <div>
      <Navbar/>
      <div className="flex justify-center items-center">
       <DashboardComp/>
      </div>
    </div>
  )
}
