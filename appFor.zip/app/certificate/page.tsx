import React from 'react'
import Navbar from '../components/navbar'
import CertificateComp from '../components/certificateComp'

export default function Page() {
  return (
    <div>
        <Navbar/>
      <div className="flex justify-center items-center border border-gray-500 mx-40 my-4">
       <CertificateComp/>
      </div>
    </div>
  )
}
