'use client'
import Navbar from '../components/navbar'
import UserProfile from '../components/userProfile'
import { useState, useEffect } from 'react'
import { User } from '@/models/user.models';
import Footer from '../components/footer';

export default function Page() {

  const [userData, setUserData] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchUser() {
      try {
        const res = await fetch("/api/user");
        const result = await res.json();


        setUserData(result.data);

      } catch (error) {
        console.log("something went wrong in user page")
      }
      finally {
        setLoading(false)
      }
    }
    fetchUser();
  }, [])

if(loading){
  return <div>Loading</div>
}
  if(!userData){
    return <div>user does not exist</div>
  }
  return (
      
    <div>
      <Navbar />
      <div className="flex h-[500px] justify-center items-center bg-slate-800/20">
        <UserProfile
          username={userData.username}
          usertype={userData.usertype}
          userId={userData.userId}
          email={userData.email}
          mobileNo={userData.mobileNo}
          dateOfRegistration={userData.dateOfRegistration}
          address={userData.address}
          accountStatus= {userData.accountStatus ? "Active" : "Inactive"}
        />
      </div>
      <Footer/>
    </div>
  )
}
