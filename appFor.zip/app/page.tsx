import Image from "next/image";
import Navbar from "./components/navbar";
import Base from "./components/home";

export default function Home() {
  return (
    <div className="bg-white h-screen ">
      <Navbar/>
      <Base/>
    </div>
  );
}
