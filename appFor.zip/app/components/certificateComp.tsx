import React from "react";

export default function CertificateComp() {
  return (
    <div className="p-10 space-y-6">

      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold">My Certificates</h1>
        <p className="text-sm text-gray-600">
          Download your approved certificates
        </p>
      </div>

      {/* Certificate Table */}
      <div className="bg-white border rounded-lg overflow-hidden">

        {/* Table Header */}
        <div className="grid grid-cols-5 bg-gray-100 px-4 py-3 text-sm font-semibold">
          <span>Certificate</span>
          <span>Application ID</span>
          <span>Issued On</span>
          <span>Status</span>
          <span>Action</span>
        </div>

        {/* Row 1 */}
        <div className="grid grid-cols-5 px-4 py-3 border-t text-sm items-center">
          <span>Income Certificate</span>
          <span>APP-10234</span>
          <span>12-Apr-2025</span>
          <span className="text-green-700 font-medium">Approved</span>
          <button className="text-blue-700 hover:underline">
            Download
          </button>
        </div>

        {/* Row 2 */}
        <div className="grid grid-cols-5 px-4 py-3 border-t text-sm items-center">
          <span>Caste Certificate</span>
          <span>APP-10235</span>
          <span>18-Apr-2025</span>
          <span className="text-green-700 font-medium">Approved</span>
          <button className="text-blue-700 hover:underline">
            Download
          </button>
        </div>

        {/* Row 3 (Pending example) */}
        <div className="grid grid-cols-5 px-4 py-3 border-t text-sm items-center">
          <span>Residence Certificate</span>
          <span>APP-10236</span>
          <span>—</span>
          <span className="text-yellow-600 font-medium">Pending</span>
          <button
            disabled
            className="text-gray-400 cursor-not-allowed"
          >
            Not Available
          </button>
        </div>

      </div>

    </div>
  );
}
