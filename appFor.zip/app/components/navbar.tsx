"use client";
import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";

export default function Navbar() {
  return (
    <div>
      {/* logobar */}
      <div id="logobox" className="flex flex-row justify-between">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/8/84/Government_of_India_logo.svg"
          className="h-[80px]"
          alt=""
        />
        <div className="flex flex-row items-center">
          {/* call us on */}
          <div className="mr-3">
            <div className=" font-bold flex items-center gap-2">
              <img src="/call.png" className="h-4 w-4" alt="language icon" />
              <span className="text-gray-400">Call Us</span>
            </div>
          </div>
          {/* language */}
          <div className=" font-bold flex items-center gap-2">
            <img src="/internet.png" className="h-4 w-4" alt="language icon" />
            <span className="text-gray-400">English</span>
          </div>
          <span className=""></span>
          {/* buttons */}
          <div id="buttons" className="m-2">
            <button className="text-white bg-blue-600 border rounded-3xl border-gray-500 mx-2 px-3 py-2">
              <Link href="/login">Login</Link>
              
            </button>
            <button className="text-white bg-blue-600 border rounded-3xl border-gray-500  px-3 py-2">
              Register
            </button>
          </div>
        </div>
      </div>

      {/* Navbar */}
      <div className=" bg-blue-950 text-white  max-w-full w-auto h-12">
        <div className="flex justify-between items-center h-full">
          <ul className="flex flex-row justify-between font-bold mx-10 gap-6">
            <motion.li whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link href="./">Home</Link>
            </motion.li>
            <motion.li whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link href="./user">User</Link>
            </motion.li>
            <motion.li whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link href="./apply">Application</Link>
            </motion.li>

            
             <motion.li whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link href="./dashboard">Dashboard</Link>
            </motion.li>

             <motion.li whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link href="./certificate">Certificates</Link>
            </motion.li>
            <motion.li whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link href="./AboutUs">About Us</Link>
            </motion.li>
          </ul>
          <div className="gap-4 flex flex-row items-center">
            <input
              type="text"
              placeholder="Search"
              className="rounded-4xl bg-white/30 border border-gray-300 pl-2"
            />
            <motion.img
              src="/search.png"
              alt=""
              className="h-[20px] pr-10"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
