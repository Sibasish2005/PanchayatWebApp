import React from 'react'

export default function Footer() {
  return (
    <div>
      <div className="bg-gray-800 h-[300px] w-screen"></div>
    </div>
  )
}
