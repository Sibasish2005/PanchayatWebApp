import React from "react";
type UserDataProps = {
   username: string,
    usertype: string,
    userId: string,
    email: string,
    mobileNo: string,
    dateOfRegistration: string,
    address: string,
    accountStatus: boolean | string,
}


export default function UserProfile({username,usertype,userId,email,mobileNo,dateOfRegistration,address,accountStatus}:UserDataProps) {

  return (
    <div className="bg-white border border-gray-300 rounded-lg">
      {/* Top User Bar */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center gap-4">
          <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJkAAACUCAMAAAC3HHtWAAAAM1BMVEX///+xsbGtra3w8PCoqKj6+vr09PS3t7fAwMC7u7vDw8PQ0NDNzc3s7Ozk5OTU1NTb29u9l4yvAAAEnklEQVR4nO1c23LrIAw02PgWjP3/X3vipJ2kbZB2MSScGe9bpxPNGsRKCEHTnDhx4sSJEwfQh231fh7HcfZ+3UL/aUJN45ZwmUzXddaab1h7/dtMl7C4j9Ha5sk8UfqJ6z+meXs/OdeuQxcj9USvG9b2rey20ei0vsiZcXsXrdZHpzA2sb59A6/Fw8P1PHB+KcyrnRN43bnNJcet92m0vsj5Yjq3JY7XY9zKrIVl7A7x2tGNBdxtO0zrjtzD1k/HJvIBO2X1tmXIRexKbcg4o+txD3tGt+YidkgrXsH6LLxcNhd7ojZlCPNuzE/sSm08TM0NBXjtGA5S66dCxIw5qB6lRmzHcICXGwsSM+aAr80lnP8BO6cSyyywf5EquaHsiO2wIYVYX57YlVrCAi2jsH+YJayC7MEyQo0OoQtNbC8adMDu+PfPyJyIDErWDPMalnYJ615RoH5LhqmVsW67OTzMu3ChRs5S0sGty/n3AuN2f9T6pMT/1Z4jEN7AhIJA8Bpef7FjkhRYb5lAHs9lZtwILGqMYsR9hBg1WDlwHxFN9vj3TRgx3MvsRTS04WOPeRq+MDWRhP0VW564lqkaGeAED9K0Cz4Hqi14ESh+cQfMC0gTiCCnE8MzWSAhXfDP1I152JjRVajHBUidAMJWJC79AB5NVGuE/iNVEzxEqXGAWJmIcBPMtNUJW7rG4azMtNXpiM1v3jEznewczO4XSeCJfErRDUIzDFAJpvJHWTeY4k9WpTWK3xJqBkUnIg9SFI36RmNUR+MqlpJ3cDtzdTpbqswlai01+hkzxzsz6UiKiAA3yKkjszk0ShSgy5/SOS9bsBdTbrrGLkV1+jOloEIX2e0cpcYX4KQyPGsrflzpUuriArMEa6+PK/uUWqoVmCWV2bv1T5WKVJ9vQ7mZXYftBze3JZ475md270wKS9vu5dCJr9UWZGZuXV1mMPGur4PM3lNpj0FaAR8lJqpGynHmbRqHvcPxhnkcUidVUlo6OnV28lv41Zbn2rD5ydJOK0UnTrj3drw+Fp1cTzT23c1JEZ3Jguy0ah1l7coom5gF4dptDdT36YjOMDFzxLNtjxbKHbxRFLNtdIdCneXCu2uxUA7Jhh25k1ww8ZDrVMiewtLtKQ5qEpMrOIhTJHQbQVUEeWMN+IRN6T5tAbuy7+pVKnFtx6HrkVKl0mN6YucYMJ+KBTUKJPV+NPq2WK2Galqb3gClCJJaQVYU7UCHorL/1Gv4sm506R2ni7y49E+WdcOmt4w52TDgv+KXFWMGnIjJq7MUM+gUUTx5LcYMyhGklLsQM7CZRNLEUmMG6rcgaYWYgV0RUhwowwzuJBG6b8oww1sK455WhhmRJUSXZwlmVMNvVNOKMKP2O7FGiwLMuG7C6CmDbdMRYcbuxGLK0aUj8q10XlVtp2/F3dH1dpRX3IVf8c2Fim97VHxDpt5bRTXfxKr39lrFN/4qviXZ1HuztKn4Nm7FN5grvvXd1HtTvqn4dYGm3hcZmopfsWjqffljR62vpeyo9YWZGyp9lWdHtS8Z3dlV+frTN7k6X8x6oMJXxk6cOHHixP+Mf2vFP6eHFlhDAAAAAElFTkSuQmCC"
            alt="User"
            className="h-12 w-12 rounded-full border"
          />
          <div>
            <p className="font-semibold text-gray-900">{username}</p>
            <p className="text-sm text-gray-600">{usertype}</p>
          </div>
        </div>

        <button className="text-sm text-blue-700 hover:underline">
          Edit Profile
        </button>
      </div>

      {/* User Details */}
      <div className="p-6 grid grid-cols-2 gap-y-4 gap-x-10 text-sm">
        <div>
          <p className="text-gray-500">User ID</p>
          <p className="font-medium">{userId}</p>
        </div>

        <div>
          <p className="text-gray-500">Email</p>
          <p className="font-medium">{email}</p>
        </div>

        <div>
          <p className="text-gray-500">Mobile Number</p>
          <p className="font-medium">{mobileNo}</p>
        </div>

        <div>
          <p className="text-gray-500">Date of Registration</p>
          <p className="font-medium">{dateOfRegistration}</p>
        </div>

        <div>
          <p className="text-gray-500">Address</p>
          <p className="font-medium">{address}</p>
        </div>

        <div>
          <p className="text-gray-500">Account Status</p>
          <p className="font-medium text-green-700">{accountStatus}</p>
        </div>
      </div>
    </div>
  );
}
