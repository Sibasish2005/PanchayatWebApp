import React from 'react'

export default function DashboardComp() {
  return (
    <div className='bg-slate-950/20 h-screen w-full mx-40 my-4'>
       <div className="p-10 space-y-8">

      {/* Page Title */}
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-gray-600">
          Overview of your applications
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-white border rounded-lg p-4">
          <p className="text-sm text-gray-500">Total Applications</p>
          <p className="text-2xl font-bold">12</p>
        </div>

        <div className="bg-white border rounded-lg p-4">
          <p className="text-sm text-gray-500">Pending</p>
          <p className="text-2xl font-bold text-yellow-600">5</p>
        </div>

        <div className="bg-white border rounded-lg p-4">
          <p className="text-sm text-gray-500">Approved</p>
          <p className="text-2xl font-bold text-green-700">6</p>
        </div>

        <div className="bg-white border rounded-lg p-4">
          <p className="text-sm text-gray-500">Rejected</p>
          <p className="text-2xl font-bold text-red-600">1</p>
        </div>
      </div>

      {/* Application Status Section */}
      <div className="bg-white border rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">
          Application Status
        </h2>

        <div className="space-y-3 text-sm">
          <div className="flex justify-between border-b pb-2">
            <span>Income Certificate</span>
            <span className="text-yellow-600 font-medium">Pending</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span>Caste Certificate</span>
            <span className="text-green-700 font-medium">Approved</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span>Residence Certificate</span>
            <span className="text-green-700 font-medium">Approved</span>
          </div>

          <div className="flex justify-between">
            <span>Birth Certificate</span>
            <span className="text-red-600 font-medium">Rejected</span>
          </div>
        </div>
      </div>

      {/* Recent Activity (Extra Feature) */}
      <div className="bg-white border rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">
          Recent Activity
        </h2>

        <ul className="text-sm space-y-3">
          <li>
            📄 Income Certificate application submitted  
            <span className="text-gray-500"> — 2 days ago</span>
          </li>
          <li>
            ✅ Caste Certificate approved  
            <span className="text-gray-500"> — 5 days ago</span>
          </li>
          <li>
            ❌ Birth Certificate rejected  
            <span className="text-gray-500"> — 7 days ago</span>
          </li>
        </ul>
      </div>

    </div>
    </div>
  )
}
