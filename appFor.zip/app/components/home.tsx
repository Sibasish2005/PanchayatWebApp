'use client'
import React from "react";
import { motion } from "framer-motion";



export default function Base() {
  return (
    <div className="w-full">
      <div
        className="
          flex flex-col lg:flex-row
          min-h-screen
          px-4 sm:px-6 md:px-10 lg:px-20
          py-4
          gap-4
        "
      >
        <div
          className="
            bg-slate-600/10 rounded-lg
            w-full lg:w-[35%]
            p-4 sm:p-6 md:p-8 lg:p-10
          "
        >
          <div className="bg-black/10 h-full rounded-xl flex flex-col items-center">
            <div className="pb-4 flex flex-col items-center">
              <h1 className="text-center text-xl sm:text-2xl font-bold">
                QuickLinks
              </h1>
              <motion.div
                key="quicklinks-underline"
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ scaleX: 1, opacity: 1 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                style={{ transformOrigin: "center" }}
                className="bg-blue-950 h-1 w-16 sm:w-20 rounded-full"
              />
            </div>

            <div className="w-full">
              <ul className="bg-white w-full rounded-b-xl overflow-hidden">

                <li

                  className="border border-gray-200 h-[48px]"
                ></li>

              </ul>
            </div>
          </div>
        </div>

      
        <div
          className="
            rounded-lg
            w-full lg:w-[65%]
          "
        >
          {/* img section */}
          <div className="p-4 sm:p-6 md:p-8 lg:p-10">
            <img
              src="/banner.png"
              alt="banner"
              className="w-full h-auto rounded-lg object-cover"
            />
          </div>

          {/* latest section */}
          <div className="px-4 sm:px-6 md:px-8 lg:px-10">
            <div className="pt-6 pb-4 flex flex-col items-center">
              <h1 className="text-center text-xl sm:text-2xl font-bold">
                Latest Updates
              </h1>
              <div className="bg-blue-950 h-1 w-16 sm:w-20 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
