import React from 'react'
import Navbar from '../components/navbar'
import Application from '../components/application'

export default function page() {
  return (
    <div>
      <Navbar/>
      <Application/>
    </div>
  )
}
